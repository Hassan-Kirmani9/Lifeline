﻿using LifeLineApi.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace LifeLineApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Admin_Cr : ControllerBase
    {
        private readonly LifeLinedbContext _dbContext;

        public Admin_Cr(LifeLinedbContext dbContext)
        {
            _dbContext = dbContext;
        }
        //Contact Start
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ApplicationAdmin>>> GetAdminAvailability()
        {
            if (_dbContext.ApplicationAdmins == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.ApplicationAdmins.ToListAsync();

            return stud;
        }

        [HttpPost]

        public async Task<ActionResult<ApplicationAdmin>> PostAdmin(ApplicationAdmin s)
        {


            User t = new User();
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(s.AaPassword.ToString());

            

            t.Email = s.AaEmail;
            t.Password = hashedPassword; ;

            t.RoleId = 1;

            _dbContext.Users.Add(t);
            _dbContext.ApplicationAdmins.Add(s);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAdminAvailability), new { id = s.AaId }, s);

        }

        [HttpPut]
        public async Task<ActionResult> PutAdminAvailability(int id, ApplicationAdmin s)
        {
            // Retrieve the existing admin entity
            var existingAdmin = await _dbContext.ApplicationAdmins.FindAsync(id);
            if (existingAdmin == null)
            {
                return NotFound();
            }

            // Update the password if it is provided
            if (!string.IsNullOrEmpty(s.AaPassword))
            {
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(s.AaPassword);
                existingAdmin.AaPassword = hashedPassword;
            }

            

            // Update the user password if necessary
            var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.RoleId == 1);
            if (user != null && !string.IsNullOrEmpty(s.AaPassword))
            {
                user.Password = existingAdmin.AaPassword;
                _dbContext.Entry(user).State = EntityState.Modified;


            }

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HAdminAvailabilityAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();
        }




        private bool HAdminAvailabilityAvailable(int id)
        {
            return (_dbContext.ApplicationAdmins?.Any(x => x.AaId == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteAdminAvailability(int id)
        {
            if (_dbContext.ApplicationAdmins == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.ApplicationAdmins.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            _dbContext.ApplicationAdmins.Remove(stud);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }

        [HttpPost("ALog")]
        public IActionResult LogAdminAvailability([FromBody] ApplicationAdmin a)
        {
            try
            {
                if (_dbContext.ApplicationAdmins == null)
                {
                    return NotFound();
                }
                var stud = _dbContext.ApplicationAdmins
                  .Where(x => x.AaUserName == a.AaUserName && x.AaPassword == a.AaPassword)
                  .SingleOrDefault();

                if (stud == null)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing request: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }
        

        [HttpPost("Login")]
        public IActionResult LogAdminAvailability([FromBody] User a)
        {
            try
            {
                if (_dbContext.Users == null)
                {
                    return NotFound();
                }

                // Retrieve the user from the database based on the provided email
                var user = _dbContext.Users.FirstOrDefault(x => x.Email == a.Email);

                if (user == null)
                {
                    return NotFound();
                }

                // Verify the password
                if (BCrypt.Net.BCrypt.Verify(a.Password, user.Password))
                {
                    // Password is correct, proceed with login
                    // Create ClaimsIdentity for authentication
                    var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, a.Email) }, CookieAuthenticationDefaults.AuthenticationScheme);

                    // Sign in the user
                    HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

                    // Store user's email in session
                    HttpContext.Session.SetString("useremail", a.Email);

                    // Fetch user profile based on role
                    object userProfile = null;
                    switch (user.RoleId)
                    {
                        case 1:
                            userProfile = _dbContext.ApplicationAdmins.FirstOrDefault(admin => admin.AaEmail == a.Email);
                            break;
                        case 2:
                            userProfile = _dbContext.Hospitals.FirstOrDefault(hospital => hospital.HEmail == a.Email);
                            break;
                        case 3:
                            userProfile = _dbContext.HEmployees.FirstOrDefault(hEmployee => hEmployee.HeEmail == a.Email);
                            break;
                        case 4:
                            userProfile = _dbContext.Doctors.FirstOrDefault(doctor => doctor.DEmail == a.Email);
                            break;
                        case 5:
                            userProfile = _dbContext.Patients.FirstOrDefault(patient => patient.PEmail == a.Email);
                            break;
                        default:
                            return BadRequest("Invalid RoleId");
                    }

                    // Create response DTO
                    var userDto = new
                    {
                        role_id = user.RoleId,
                        email = user.Email,
                        userProfile
                    };

                    return Ok(userDto);
                }
                else
                {
                    // Password is incorrect
                    return Unauthorized("Invalid email or password");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing request: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }
        [HttpPost("Logout")]
        public IActionResult Logout()
        {
            // Clear cookies
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            // Add Cache-Control header to prevent caching
            Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate"; 
            Response.Headers["Pragma"] = "no-cache"; // HTTP 1.0
            Response.Headers["Expires"] = "0"; // Proxies

            return Ok();
        }
        [HttpGet("LoggedInHospital")]
        //[Authorize]
        public IActionResult GetLoggedInHospital()
        {
            var userEmail = HttpContext.User.Identity.Name; // Get user email from claims

            // Fetch hospital admin information based on userEmail from the database
            var hospitalAdmin = _dbContext.Users
                .FirstOrDefault(x => x.Email == userEmail);

            if (hospitalAdmin == null)
            {
                return NotFound();
            }

            // Return the hospital admin information
            var hospitalAdminDto = new
            {
                role_id = hospitalAdmin.RoleId,
                email = hospitalAdmin.Email,
                // Add other properties you want to expose
            };

            return Ok(hospitalAdminDto);
        }


    }
}