﻿using LifeLineApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LifeLineApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class appointment_cr : ControllerBase
    {
        private readonly LifeLinedbContext _dbContext;

        public appointment_cr(LifeLinedbContext dbContext)
        {
            _dbContext = dbContext;
        }
        //Contact Start
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Appointment>>> GetAppointments()
        {
            if (_dbContext.Appointments == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Appointments.ToListAsync();

            return stud;
        }

        [HttpGet("AppointmentHistory")]
        public async Task<ActionResult<IEnumerable<Appointment>>> GetAppointmentsHistory(string a_email)
        {
            // Fetch appointments from both Appointment and AppointmentHistories tables based on email
            var appointments = await _dbContext.Appointments
                .Where(a => a.AEmail == a_email)
                .ToListAsync();

            var appointmentHistories = await _dbContext.Appointmentshistories
                .Where(a => a.AEmail == a_email)
                .ToListAsync();

            // Combine both lists into a single list
            var combinedAppointments = appointments.Cast<object>().Union(appointmentHistories.Cast<object>());

            return Ok(combinedAppointments);
        }

        [HttpPost]

        public async Task<ActionResult<Appointment>> PostAppointment(Appointment s)
            {


            _dbContext.Appointments.Add(s);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAppointments), new { id = s.AId }, s);

        }

        [HttpPut]
        public async Task<ActionResult> PutAppointment(int id, Appointment s)
        {
            if (id != s.AId)
            {
                return BadRequest();
            }
            _dbContext.Entry(s).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {


                if (!HAppointmentAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();

        }

        private bool HAppointmentAvailable(int id)
        {
            return (_dbContext.Appointments?.Any(x => x.AId == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteAppointment(int id)
        {
            if (_dbContext.Appointments == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Appointments.FindAsync(id);

            if (stud == null)
            {
                var studd = await _dbContext.Appointmentshistories.FindAsync(id);
                if (studd == null)
                {
                    return NotFound();
                }
                else
                {
                    _dbContext.Appointmentshistories.Remove(studd);
                    await _dbContext.SaveChangesAsync();
                    return Ok();
                }

            }
            _dbContext.Appointments.Remove(stud);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }

        //[HttpGet("appointments")]
        //public async Task<ActionResult<IEnumerable<Appointment>>> GetAppointments([FromQuery] int hospitalId)
        //{
        //    try
        //    {

        //        var doctors = await _dbContext.Doctors
        //            .Where(d => d.DHId == hospitalId)
        //            .ToListAsync();


        //        var doctorIds = doctors.Select(d => d.DId).ToList();


        //        var appointments = await _dbContext.Appointments
        //            .Where(a => doctorIds.Contains(a.ADId.Value))
        //            .Select(a => new Appointment
        //            {
        //                AId = a.AId,
        //                AHId = a.AHId,
        //                ADId = a.ADId,
        //                APatientDob = a.APatientDob,
        //                APatientName = a.APatientName,
        //                ADate = a.ADate,
        //                ATime = a.ATime,
        //                AMobile = a.AMobile,
        //                AType = a.AType,
        //                AReason = a.AReason,
        //                AD = a.AD,



        //            })
        //            .ToListAsync();

        //        return Ok(appointments);
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"Internal Server Error: {ex.Message}");
        //    }
        //}

        [HttpGet("appointments")]
        public async Task<ActionResult<IEnumerable<Appointment>>> GetAppointments([FromQuery] int hospitalId)
        {
            try
            {
                // Fetch doctors based on hospital ID
                var doctors = await _dbContext.Doctors
                    .Where(d => d.DHId == hospitalId)
                    .ToListAsync();

                // Get doctor IDs from fetched doctors
                var doctorIds = doctors.Select(d => d.DId).ToList();

                // Get today's date
                var today = DateTime.Today;

                // Fetch appointments from the Appointments table
                var appointments = await _dbContext.Appointments
                    .Where(a => doctorIds.Contains(a.ADId.Value) && a.ADate >= today && !(a.AType == "Accepted online" || a.AType == "Accepted"))
                    .Select(a => new Appointment
                    {
                        AId = a.AId,
                        AHId = a.AHId,
                        ADId = a.ADId,
                        APatientDob = a.APatientDob,
                        APatientName = a.APatientName,
                        ADate = a.ADate,
                        ATime = a.ATime,
                        AMobile = a.AMobile,
                        AEmail = a.AEmail,
                        AType = a.AType,
                        AReason = a.AReason,
                        AD = a.AD,
                    })
                    .ToListAsync();

                // Fetch appointments from the Appointmentshistory table
                var appointmentHistory = await _dbContext.Appointmentshistories
              .Where(a => doctorIds.Contains(a.ADId.Value) && a.ADate >= today && !(a.AType == "Accepted online" || a.AType == "Accepted"))
              .Select(a => new Appointment
              {
                        AId = a.AId,
                        AHId = a.AHId,
                        ADId = a.ADId,
                        APatientDob = a.APatientDob,
                        APatientName = a.APatientName,
                        ADate = a.ADate,
                        ATime = a.ATime,
                        AMobile = a.AMobile,
                        AEmail = a.AEmail,
                        AType = a.AType,
                        AReason = a.AReason,
                        AD = a.AD,
                    })
                    .ToListAsync();


                // Combine both lists
                var combinedAppointments = appointments.Concat(appointmentHistory).ToList();

                return Ok(combinedAppointments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }



    }
}
