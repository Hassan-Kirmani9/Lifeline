﻿using LifeLineApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks.Dataflow;
using System.Web;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.TwiML.Messaging;
using Twilio.TwiML.Voice;
using Twilio.Types;


namespace LifeLineApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class patient_cr : ControllerBase
    {
        private readonly LifeLinedbContext _dbContext;
        private readonly TwilioSmsService _smsService;

        public patient_cr(LifeLinedbContext dbContext, TwilioSmsService smsService)
        {
            _dbContext = dbContext;
            _smsService = smsService;
        }
        //Contact Start
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Patient>>> Getpatients()
        {
            if (_dbContext.Patients == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Patients.ToListAsync();

            return stud;
        }

        [HttpPost("Realtimewaitingupdate")]
        public IActionResult Realtimewaitingupdate()
        {
            var currentDate = DateTime.Now.Date;
            var email = _dbContext.Realtimewaitingtbs.Where(x => x.PDate == currentDate && x.Status == "enquee").ToList();


            foreach (var job in email)
            {
                try
                {
                    MailMessage mm = new MailMessage();
                    mm.From = new MailAddress("fyplifeline@gmail.com");
                    mm.To.Add(new MailAddress(job.PEmail));
                    mm.Subject = "Appointment Reminder";
                    string dateString = job.PDate?.ToString("yyyy-MM-dd");



                    string timeString = job.PTime?.ToString();


                    string timeAmPm = DateTime.ParseExact(timeString, "HH:mm:ss", CultureInfo.InvariantCulture).ToString("hh:mm tt");


                    string body = @"
            <html>
            <head>
                <style>
                    /* Define styles for the email body */
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f2f2f2;
                        color: #333333;
                    }
                    .container {
                        margin: 20px auto;
                        padding: 20px;
                        background-color: #ffffff;
                        border-radius: 10px;
                        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
                    }
                    .content {
                        text-align: center;
                    }
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        background-color: #007bff;
                        color: white;
                        text-decoration: none;
                        border-radius: 5px;
                    }
                    .highlight {
                        font-weight: bold;
                        color: #ff5733; /* orange color */
                    }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='content'>
                        <h2>Appointment Reminder</h2>
                        <p>
                            Hi,<br/><br/>
                            We wanted to remind you of your appointment with LifeLine scheduled for <span class='highlight'>" + dateString + @"</span> at <span class='highlight'>" + timeAmPm + @"</span>.<br/><br/>
                        </p>
                        <p>
                            Please either visit our hospital or log in to our website to proceed with your appointment.
                        </p>
                        <p>
                            We wish you a pleasant and healthy visit!
                        </p>
                        <a href='https://dlifeline.lawseer.co/' class='button'>Login to LifeLine</a>
                    </div>
                </div>
            </body>
            </html>
        ";

                    mm.Body = body;
                    mm.IsBodyHtml = true;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");
                    smtp.Credentials = nc;
                    try
                    {
                        smtp.Send(mm);
                        job.Status = "sent";
                        _dbContext.Update(job);
                        _dbContext.SaveChanges();


                        //work sms

                        try
                        {
                            string sms = "Your Appointment at " + timeAmPm;
                            string n = "+92" + job.PNumber;
                            _smsService.SendSmsAsync(n, sms);
                            return Ok("SMS Sent!");
                        }
                        catch (Exception ex)
                        {
                            // Log the exception or handle it appropriately
                            return StatusCode(500, $"Failed to send SMS: {ex.Message}");
                        }


                        //end sms
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error sending email: " + ex.Message);
                        job.Status = "failed";
                    }

                    _dbContext.Update(job);
                }
                catch (Exception ex)
                {
                    return BadRequest($"Error processing job : {ex.Message}");
                }
            }


            _dbContext.SaveChanges();

            return Ok("Jobs processed successfully");

        }
        [HttpPost]

        public async Task<ActionResult<Patient>> PostPatient(Patient s)
        {
            var hospital = _dbContext.Doctors
.Where(x => x.DId == s.PDId)
.Select(x => x.DH)
.FirstOrDefault();

            var existingPatient = _dbContext.Patients
                .Where(x => x.PEmail == s.PEmail && x.PD.DH.HId == hospital.HId)
                .FirstOrDefault();

            if (existingPatient == null)
            {

               


                MailMessage mm = new MailMessage();
                mm.From = new MailAddress("fyplifeline@gmail.com");
                mm.To.Add(new MailAddress(s.PEmail));

                Random emailrandomnum = new Random();
                int emailrandomnumber = emailrandomnum.Next(1000, 10000);

                mm.Subject = "Login credentials";
                mm.Body = "Click On the following link to log into LifeLine";
                mm.Body = "Hi," + "<br/><br/>" + "We got request for  your account creation. Please click on the below link to Login an account" +
                    "<br/><br/> Password  is : " + emailrandomnumber + "<br/><br/>";
                mm.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;

                NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                smtp.UseDefaultCredentials = true;
                smtp.Credentials = nc;
                smtp.UseDefaultCredentials = false;

                smtp.Send(mm);
                s.PPassword = emailrandomnumber.ToString();
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(emailrandomnumber.ToString());
                User t = new User();
                t.Email = s.PEmail;
                t.Password = hashedPassword;

                t.RoleId = 5;

                s.PPassword = hashedPassword;

                _dbContext.Users.Add(t);


                _dbContext.Patients.Add(s);

                _dbContext.SaveChanges();

                await _dbContext.SaveChangesAsync();

                return CreatedAtAction(nameof(Getpatients), new { id = s.PId }, s);
            }
            else
            {
                return StatusCode(403, "Patient with this Email already exists! ");
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> PutPatient(int id, Patient model)
        {
            try
            {

                var existingPatient = await _dbContext.Patients.FindAsync(id);

                if (existingPatient == null)
                {
                    return NotFound();
                }

                // Update patient properties based on the provided model
                if (model.PName != null)
                {
                    existingPatient.PName = model.PName;
                }
                if (model.PDob != null)
                {
                    existingPatient.PDob = model.PDob;
                }
                if (model.PMobile != null)
                {
                    existingPatient.PMobile = model.PMobile;
                }
                if (model.PDate != null)
                {
                    existingPatient.PDate = model.PDate;
                }
                if (model.PTime != null)
                {
                    existingPatient.PTime = model.PTime;
                }
                if (model.PAStatus != null)
                {
                    existingPatient.PAStatus = model.PAStatus;
                }
                if (model.PReason != null)
                {
                    existingPatient.PReason = model.PReason;
                }

                if (model.PPassword != null)
                {
                    // Hash the new password
                    string hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.PPassword);

                    // Update patient's password
                    existingPatient.PPassword = hashedPassword;

                    // Update password for the associated user (assuming a one-to-one relationship between patients and users)
                    var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == existingPatient.PEmail);
                    if (user != null)
                    {
                        user.Password = hashedPassword;
                    }
                    else
                    {
                        // Handle the case where the user associated with the patient's email is not found
                        // This could indicate a data inconsistency or an error in the application logic
                        // You may want to log an error or handle this situation based on your application's requirements
                    }
                }

                _dbContext.Entry(existingPatient).State = EntityState.Modified;

                try
                {
                    await _dbContext.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HPatientAvailable(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Ok();

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing request: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }


        private bool HPatientAvailable(int id)
        {
            return (_dbContext.Patients?.Any(x => x.PId == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeletePatient(int id)
        {
            if (_dbContext.Patients == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Patients.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            _dbContext.Patients.Remove(stud);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }
        [HttpGet("patients")]
        public async Task<ActionResult<IEnumerable<Patient>>> GetPatients([FromQuery] int hospitalId)
        {
            try
            {
               
                var patients = await _dbContext.Patients
                    .Where(p => p.PD != null && p.PD.DHId == hospitalId)
                    .Include(p => p.PD) 
                        .ThenInclude(d => d.DH) 
                    .Select(p => new Patient
                    {
                        PId = p.PId,
                        PName = p.PName,
                        PDob = p.PDob,
                        PDate = p.PDate,
                        PMobile = p.PMobile,
                        PTime = p.PTime,
                        PReason = p.PReason,
                        PEmail = p.PEmail,
                        PDId = p.PDId,
                        PD = new Doctor
                        {
                            DId = p.PD.DId,
                            DName = p.PD.DName,
                            DField = p.PD.DField,
                            DHId = p.PD.DHId, 
                            DH = new Hospital
                            {
                               
                                HId = p.PD.DH.HId,
                                HName = p.PD.DH.HName,
                                HAddress = p.PD.DH.HAddress,
                               
                            }
                        }
                    })
                    .ToListAsync();

                return Ok(patients);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
        [HttpGet("Docpre")]

        public ActionResult GetPrescriptionById(int id)
        {
            if (_dbContext.DoctorPrescriptions == null)
            {
                return NotFound();
            }
            var stud = _dbContext.DoctorPrescriptions.Where(x => x.DpPId == id).SingleOrDefault();

            if (stud == null)
            {
                return NotFound();
            }
            return Ok(stud);
        }

        [HttpPost("Accept(\"{id}\")")]
        public IActionResult AcceptAppointment(Patient p, int id)
        {
            try
            {
                var appointment = _dbContext.Appointments.Find(id);

                if (appointment!=null)
                {
                    // Retrieve hospital information from the doctor associated with the appointment
                    var hospital = _dbContext.Doctors
                        .Where(x => x.DId == appointment.ADId)
                        .Select(x => x.DH)
                        .FirstOrDefault();



                    // Check if a patient with the same email exists in the same hospital
                    var existingPatient = _dbContext.Patients
                        .Where(x => x.PEmail == appointment.AEmail && x.PD.DH.HId == hospital.HId)
                        .FirstOrDefault();

                    if (existingPatient != null)
                    {
                        Appointmentshistory tt = new Appointmentshistory();

                        tt.APatientName = appointment.APatientName;
                        tt.ADId = appointment.ADId;
                        tt.APatientDob = appointment.APatientDob;
                        tt.AMobile = appointment.AMobile;
                        tt.ADate = appointment.ADate;
                        tt.ATime = appointment.ATime;
                        tt.AHId = appointment.AHId;

                        if (appointment.AType == "online")
                        {
                            tt.AType = "Accepted online";
                        }
                        else
                        {
                            tt.AType = "Accepted";
                        }
                        tt.AReason = appointment.AReason;
                        tt.AEmail = appointment.AEmail;

                        _dbContext.Appointmentshistories.Add(tt);
                        _dbContext.Appointments.Remove(appointment);
                        _dbContext.SaveChanges();


                        MailMessage mmm = new MailMessage();
                        mmm.From = new MailAddress("fyplifeline@gmail.com");
                        mmm.To.Add(new MailAddress(tt.AEmail));



                        mmm.Subject = "Appointment Succesfull - LifeLine";
                        mmm.Body = "Click On the following link to log into LifeLine";
                        mmm.Body = "Hi," + "<br/><br/>" + " Please click on the below link to Login an account" +
                            "<br/><br/>" +
                                "<a href='https://dlifeline.lawseer.co/admin/Login'>Login Link</a>";
                        mmm.IsBodyHtml = true;

                        SmtpClient smtpp = new SmtpClient();
                        smtpp.Host = "smtp.gmail.com";
                        smtpp.Port = 587;
                        smtpp.EnableSsl = true;

                        NetworkCredential ncc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                        smtpp.UseDefaultCredentials = true;
                        smtpp.Credentials = ncc;
                        smtpp.UseDefaultCredentials = false;

                        smtpp.Send(mmm);

                        return Ok("Appointment accepted successfully");
                    }

                }
                else
                {
                    var appointmenth = _dbContext.Appointmentshistories.Find(id);

                    // Retrieve hospital information from the doctor associated with the appointment
                    var hospital = _dbContext.Doctors
                        .Where(x => x.DId == appointmenth.ADId)
                        .Select(x => x.DH)
                        .FirstOrDefault();

                    if (appointmenth.AType == "online")
                    {
                        appointmenth.AType = "Accepted online";
                    }
                    else
                    {
                        appointmenth.AType = "Accepted";
                    }
                    _dbContext.SaveChanges();


                    MailMessage mmm = new MailMessage();
                    mmm.From = new MailAddress("fyplifeline@gmail.com");
                    mmm.To.Add(new MailAddress(appointmenth.AEmail));



                    mmm.Subject = "Appointment Succesfull - LifeLine";
                    mmm.Body = "Click On the following link to log into LifeLine";
                    mmm.Body = "Hi," + "<br/><br/>" + " Please click on the below link to Login an account" +
                        "<br/><br/>" +
                            "<a href='https://dlifeline.lawseer.co/admin/Login'>Login Link</a>";
                    mmm.IsBodyHtml = true;

                    SmtpClient smtpp = new SmtpClient();
                    smtpp.Host = "smtp.gmail.com";
                    smtpp.Port = 587;
                    smtpp.EnableSsl = true;

                    NetworkCredential ncc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                    smtpp.UseDefaultCredentials = true;
                    smtpp.Credentials = ncc;
                    smtpp.UseDefaultCredentials = false;

                    smtpp.Send(mmm);

                    return Ok("Appointment accepted successfully");
                }

                p.PName = appointment.APatientName;
                p.PDId = appointment.ADId;
                p.PDob = appointment.APatientDob;
                p.PMobile = appointment.AMobile;
                p.PDate = appointment.ADate;
                p.PTime = appointment.ATime;
               
                if (appointment.AType == "online")
                {
                    p.PAStatus = "Accepted online";
                }
                else
                {
                    p.PAStatus = "Accepted";
                }
                p.PReason = appointment.AReason;
                p.PEmail = appointment.AEmail;                
                MailMessage mm = new MailMessage();
                mm.From = new MailAddress("fyplifeline@gmail.com");
                mm.To.Add(new MailAddress(p.PEmail));

                Random emailrandomnum = new Random();
                int emailrandomnumber = emailrandomnum.Next(1000, 10000);

                mm.Subject = "Appointment Succesfull - LifeLine";
                mm.Body = "Click On the following link to log into LifeLine";
                mm.Body = "Hi," + "<br/><br/>" + "We got request for  your account creation. Please click on the below link to Login an account" +
                    "<br/><br/> Password  is : " + emailrandomnumber + "<br/><br/>" +
                        "<a href='https://dlifeline.lawseer.co/admin/Login'>Login Link</a>";
                mm.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;

                NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                smtp.UseDefaultCredentials = true;
                smtp.Credentials = nc;
                smtp.UseDefaultCredentials = false;

                smtp.Send(mm);
                p.PPassword = emailrandomnumber.ToString();
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(emailrandomnumber.ToString());

                User t = new User();
                t.Email = p.PEmail;
                t.Password = hashedPassword;
                p.PPassword = hashedPassword;

                t.RoleId = 5;

                _dbContext.Users.Add(t);



                _dbContext.Patients.Add(p);
                _dbContext.Appointments.Remove(appointment);
                _dbContext.SaveChanges();

                return Ok("Appointment accepted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error accepting appointment: {ex.Message}");
            }
        }

        //[HttpGet("doctorpatient")]
        //public async Task<ActionResult<IEnumerable<Patient>>> GetAcceptedPatients([FromQuery] int pdId)
        //{
        //    try
        //    {

        //        DateTime today = DateTime.Today;

        //        // Fetch all patient IDs with prescriptions recorded for today
        //        var patientIdsWithPrescriptionsToday = await _dbContext.DoctorPrescriptions
        //            .Where(dp => dp.DpDate == today)
        //            .Select(dp => dp.DpId)
        //            .ToListAsync();

        //        // Fetch patient records excluding those with prescriptions recorded for today
        //        var patients = await _dbContext.Patients
        //            .Where(p => p.PD != null &&
        //                         (p.PAStatus != "Reject" || p.PAStatus.Contains("online")) &&
        //                         p.PDate >= today &&
        //                         p.PDId == pdId &&
        //                         !patientIdsWithPrescriptionsToday.Contains(p.PId))
        //            .Include(p => p.PD)
        //                .ThenInclude(d => d.DH)
        //            .Select(p => new Patient
        //            {
        //                PId = p.PId,
        //                PName = p.PName,
        //                PDob = p.PDob,
        //                PDate = p.PDate,
        //                PMobile = p.PMobile,
        //                PTime = p.PTime,
        //                PReason = p.PReason,
        //                PEmail = p.PEmail,
        //                PDId = p.PDId,
        //                PAStatus = p.PAStatus,
        //                PD = new Doctor
        //                {
        //                    DId = p.PD.DId,
        //                    DName = p.PD.DName,
        //                    DField = p.PD.DField,
        //                    DHId = p.PD.DHId, // Assuming this property exists in your Doctor entity
        //                    DH = new Hospital
        //                    {
        //                        // Include the properties you want from the Hospital entity
        //                        HId = p.PD.DH.HId,
        //                        HName = p.PD.DH.HName,
        //                        HAddress = p.PD.DH.HAddress,
        //                        // Include other properties as needed
        //                    }
        //                }
        //            })
        //            .ToListAsync();


        //        return Ok(patients);
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"Internal Server Error: {ex.Message}");
        //    }
        //}


        [HttpGet("doctorpatient")]
        public async Task<ActionResult<IEnumerable<Patient>>> GetAcceptedPatients([FromQuery] int pdId)
        {
            try
            {
                DateTime today = DateTime.Today;

                // Fetch all patient IDs with prescriptions recorded for today
                var patientIdsWithPrescriptionsToday = await _dbContext.DoctorPrescriptions
                    .Where(dp => dp.DpDate == today)
                    .Select(dp => dp.DpId)
                    .ToListAsync();

                // Fetch patient records excluding those with prescriptions recorded for today
                var patients = await _dbContext.Patients
                    .Where(p => p.PD != null &&
                                 (p.PAStatus != "Reject" || p.PAStatus.Contains("online")) &&
                                 p.PDate >= today &&
                                 p.PDId == pdId &&
                                 !patientIdsWithPrescriptionsToday.Contains(p.PId))
                    .Include(p => p.PD)
                        .ThenInclude(d => d.DH)
                    .Select(p => new Patient
                    {
                        PId = p.PId,
                        PName = p.PName,
                        PDob = p.PDob,
                        PDate = p.PDate,
                        PMobile = p.PMobile,
                        PTime = p.PTime,
                        PReason = p.PReason,
                        PEmail = p.PEmail,
                        PDId = p.PDId,
                        PAStatus = p.PAStatus,
                        PD = new Doctor
                        {
                            DId = p.PD.DId,
                            DName = p.PD.DName,
                            DField = p.PD.DField,
                            DHId = p.PD.DHId, // Assuming this property exists in your Doctor entity
                            DH = new Hospital
                            {
                                HId = p.PD.DH.HId,
                                HName = p.PD.DH.HName,
                                HAddress = p.PD.DH.HAddress,
                                // Include other properties as needed
                            }
                        }
                    })
                    .ToListAsync();

                // Fetch future appointments from the Appointmentshistory table
                var futureAppointments = await _dbContext.Appointmentshistories
                    .Where(a => a.ADate > today && (a.AType == "Accepted online" || a.AType == "Accepted"))
                    .Select(a => new Patient
                    {
                        PId = a.AId, // Assuming AId is the unique identifier for the appointment
                        PName = a.APatientName,
                        PDob = a.APatientDob,
                        PDate = a.ADate,
                        PMobile = a.AMobile,
                        PTime = a.ATime,
                        PReason = a.AReason,
                        PEmail = a.AEmail,
                        PDId = a.ADId ?? 0, // Provide default value if null
                        PAStatus = a.AType == "online" ? "Accepted online" : "Accepted",
                        PD = new Doctor
                        {
                            DId = a.ADId ?? 0, // Provide default value if null
                                               // Assuming you have a way to join the Doctor and Hospital entities for the appointments
                            DHId = a.AHId ?? 0 // Provide default value if null
                                               // Include other properties from the Doctor and Hospital entities as needed
                        }
                    })
                    .ToListAsync();

                // Combine the patients from the original query and the future appointments
                var combinedPatients = patients.Concat(futureAppointments).ToList();

                return Ok(combinedPatients);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }



        //send video email


        [HttpPost("Sendvideoemail")]
        public IActionResult Sendvideolinkemail(sendemail em)
        {
            try
            {
               



                
                MailMessage mm = new MailMessage();
                mm.From = new MailAddress("fyplifeline@gmail.com");
                mm.To.Add(new MailAddress(em.email));



                mm.Subject = "Video Consultation Meeting Link - LifeLine";
                mm.Body = "Hi,<br/><br/>" +
                    "Click on the following link to join the video consultation from LifeLine:<br/><br/>" +
                    "<a href='" + em.link + "'> JoinBlock Meeting </a><br/><br/>" +
                    "Doctor's Email: <br/><br/>" + em.doctor;

                mm.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;

                NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                smtp.UseDefaultCredentials = true;
                smtp.Credentials = nc;
                smtp.UseDefaultCredentials = false;

                smtp.Send(mm);
                
               

                return Ok("Sent link successfully");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error sending link: {ex.Message}");
            }
        }


    }
}

