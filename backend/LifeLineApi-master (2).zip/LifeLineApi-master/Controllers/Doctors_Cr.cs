﻿
using LifeLineApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using System.Net;
using Microsoft.AspNetCore.Hosting;


namespace LifeLineApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

   
    public class Doctors_Cr : ControllerBase
    {
        private readonly LifeLinedbContext _dbContext;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public Doctors_Cr(LifeLinedbContext dbContext, IWebHostEnvironment webHostEnvironment)
        {
            _dbContext = dbContext;
            _webHostEnvironment = webHostEnvironment;
        }

        //Doctors Start

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Doctor>>> GetDoctors()
        {
            if (_dbContext.Doctors == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Doctors.ToListAsync();

            return stud;
        }

        [HttpGet("{id}")]

        public async Task<ActionResult<Doctor>> GetDoctorsById(int id)
        {
            if (_dbContext.Doctors == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Doctors.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            return stud;
        }
        [HttpGet("ByHospitalId/{dhId}")]
        public async Task<ActionResult<IEnumerable<Doctor>>> GetDoctorsByHospitalId(int dhId)
        {
            var doctors = await _dbContext.Doctors
                .Where(doctor => doctor.DHId == dhId)
                .ToListAsync();

            if (doctors == null || doctors.Count == 0)
            {
                return NotFound();
            }

            return doctors;
        }

        [HttpPost]
        public async Task<ActionResult<Doctor>> PostDoctors([FromForm] Doctor s)
        {
            var checkemail = _dbContext.Doctors.Where(x => x.DEmail == s.DEmail).FirstOrDefault();
            var checkemailu = _dbContext.Users.Where(x => x.Email == s.DEmail).FirstOrDefault();
            if (checkemail == null && checkemailu == null)
            {
                try
            {
                MailMessage mm = new MailMessage();
                mm.From = new MailAddress("fyplifeline@gmail.com");
                mm.To.Add(new MailAddress(s.DEmail));

                Random emailrandomnum = new Random();
                int emailrandomnumber = emailrandomnum.Next(1000, 10000);

                mm.Subject = "Login credentials";
                mm.Body = "Click On the following link to log into LifeLine";
                mm.Body += "Hi," + "<br/><br/>" + "We got a request for your account creation. Please click on the below link to Login an account" +
                "<br/><br/> Password is : " + emailrandomnumber + "<br/><br/>" +
                        "<a href='https://dlifeline.lawseer.co/admin/Login'>Login Link</a>";
                mm.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;

                NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

                smtp.UseDefaultCredentials = false;
                smtp.Credentials = nc;



                if (s.ImageFile != null)
                {
                    string filename = Path.GetFileNameWithoutExtension(s.ImageFile.FileName);
                    string extension = Path.GetExtension(s.ImageFile.FileName);

                    string folder = "images_d";
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + filename + extension;

                    // Ensure the directory exists
                    string serverFolderPath = Path.Combine(_webHostEnvironment.WebRootPath, folder);
                    if (!Directory.Exists(serverFolderPath))
                    {
                        Directory.CreateDirectory(serverFolderPath);
                    }

                    string serverFilePath = Path.Combine(serverFolderPath, uniqueFileName);

                    using (var fileStream = new FileStream(serverFilePath, FileMode.Create))
                    {
                        await s.ImageFile.CopyToAsync(fileStream);
                    }

                    s.DImage = uniqueFileName;
                }
                else
                {
                    // Handle the case where ImageFile is null, perhaps by setting a default image or throwing an error.
                }

                s.DPassword = emailrandomnumber.ToString();
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(emailrandomnumber.ToString());

                    User t = new User();
                t.Email = s.DEmail;
                t.Password = hashedPassword;
                s.DPassword = hashedPassword;

                t.RoleId = 4;

                _dbContext.Users.Add(t);
                _dbContext.Doctors.Add(s);
                await _dbContext.SaveChangesAsync();
                smtp.Send(mm);
                return CreatedAtAction(nameof(GetDoctors), new { id = s.DId }, s);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
            }

            else
            {
                return StatusCode(403, "Doctor  with this Email already exists! ");
            }
        }




        [HttpPut("{id}")]
        public async Task<ActionResult> PutDoctor(int id, Doctor model)
        {
            

            var doctor = await _dbContext.Doctors.FindAsync(id);

            if (doctor == null)
            {
                return NotFound();
            }

            // Ensure email is not updated
            if (model.DEmail != null)
            {
                return BadRequest("Email cannot be updated");
            }

            // Update doctor properties
            if (model.DName != null)
            {
                doctor.DName = model.DName;
            }
            if (model.DPassword != null)
            {
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.DPassword);
                doctor.DPassword = hashedPassword;
               

                var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == doctor.DEmail);
                if (user != null)
                {
                    user.Password = hashedPassword;
                }

            }
            if (model.DMobile != null)
            {
                doctor.DMobile = model.DMobile;
            }
            if (model.DField != null)
            {
                doctor.DField = model.DField;
            }
            if (model.DAvailablityStatus != null)
            {
                doctor.DAvailablityStatus = model.DAvailablityStatus;
            }
            if (model.DImage != null)
            {
                doctor.DImage = model.DImage;
            }
            if (model.CheckinTime != null)
            {
                doctor.CheckinTime = model.CheckinTime;
            }
            if (model.CheckoutTime != null)
            {
                doctor.CheckoutTime = model.CheckoutTime;
            }
            if (model.AverageTimeToSeeOnePatient != null)
            {
                doctor.AverageTimeToSeeOnePatient = model.AverageTimeToSeeOnePatient;
            }

            // Update other properties as needed...

            _dbContext.Entry(doctor).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DoctorAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();
        }


        private bool DoctorAvailable(int id)
        {
            return (_dbContext.Doctors?.Any(x => x.DId == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteDoctor(int id)
        {
            if (_dbContext.Doctors == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Doctors.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            _dbContext.Doctors.Remove(stud);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }

        //Doctors End


        [HttpGet("returntime")]
        public async Task<ActionResult<List<DateTime>>> GetAvailableAppointmentSlots([FromQuery] DoctorAppointmentQuery query)
        {
            try
            {
                int doctorId = query.DoctorId;
                DateTime appointmentDate = query.AppointmentDate.Date;


                var doctor = await _dbContext.Doctors.FindAsync(doctorId);

                if (doctor != null)
                {

                    TimeSpan checkinTime = doctor.CheckinTime ?? TimeSpan.Zero;
                    TimeSpan checkoutTime = doctor.CheckoutTime ?? TimeSpan.Zero;
                    TimeSpan averageTimeToSeeOnePatient = doctor.AverageTimeToSeeOnePatient ?? TimeSpan.Zero;


                    var availableTimeSlots = new List<DateTime>();


                    TimeSpan currentTime = checkinTime;
                    while (currentTime.Add(averageTimeToSeeOnePatient) <= checkoutTime)
                    {
                        if (!IsAppointmentTimeTaken(doctorId, appointmentDate, currentTime))
                        {

                            availableTimeSlots.Add(new DateTime(appointmentDate.Year, appointmentDate.Month, appointmentDate.Day, currentTime.Hours, currentTime.Minutes, 0));
                        }

                        currentTime = currentTime.Add(averageTimeToSeeOnePatient);
                    }

                    return Ok(availableTimeSlots);
                }
                else
                {
                    return NotFound("Doctor not found.");
                }
            }
            catch (Exception ex)
            {

                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }



        bool IsAppointmentTimeTaken(int doctorId, DateTime appointmentDate, TimeSpan appointmentTime)
        {

            var existingAppointment = _dbContext.Appointments.Any(a => a.ADId == doctorId && a.ADate == appointmentDate && a.ATime == appointmentTime);


            return existingAppointment;
        }



    }
}
