﻿
using LifeLineApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using System.Net;
using System.Numerics;

namespace LifeLineApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]


    public class Hospital_Cr : ControllerBase
    {
        private readonly LifeLinedbContext _dbContext;

        public Hospital_Cr(LifeLinedbContext dbContext)
        {
            _dbContext = dbContext;
        }

        //Doctors Start

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Hospital>>> GetHospitals()
        {
            if (_dbContext.Hospitals == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Hospitals.ToListAsync();

            return stud;
        }

        [HttpGet("{id}")]

        public async Task<ActionResult<Hospital>> GetHospitalById(int id)
        {
            if (_dbContext.Hospitals == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Hospitals.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            return stud;
        }

        [HttpPost]

        public async Task<ActionResult<Hospital>> PostHospital(Hospital s)
        {
            var checkemail = _dbContext.Hospitals.Where(x => x.HEmail == s.HEmail).FirstOrDefault();
            var checkemailu = _dbContext.Users.Where(x => x.Email == s.HEmail).FirstOrDefault();
            if (checkemail == null && checkemailu == null)
            {
                MailMessage mm = new MailMessage();
            mm.From = new MailAddress("fyplifeline@gmail.com");
            mm.To.Add(new MailAddress(s.HEmail));

            Random emailrandomnum = new Random();
            int emailrandomnumber = emailrandomnum.Next(1000, 10000);

            mm.Subject = "Login credentials";
            mm.Body = "Click On the following link to log into LifeLine";
            mm.Body = "Hi," + "<br/><br/>" + "We got a request for your account creation. Please click on the below link to log in to your account:" +
                        "<br/><br/> Password is: " + emailrandomnumber + "<br/><br/>" +
                        "<a href='https://dlifeline.lawseer.co/admin/Login'>Login Link</a>";

            mm.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;

            NetworkCredential nc = new NetworkCredential("fyplifeline@gmail.com", "qzcw izon errs reyu");

            smtp.UseDefaultCredentials = true;
            smtp.Credentials = nc;
            smtp.UseDefaultCredentials = false;

            smtp.Send(mm);
            s.HPassword = emailrandomnumber.ToString();
                // Hash the random number before storing it as the password
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(emailrandomnumber.ToString());

                // Create a User object
                User t = new User();
                t.Email = s.HEmail;
                t.Password = hashedPassword;
                t.RoleId = 2;
                s.HPassword = hashedPassword;

                _dbContext.Users.Add(t);
            _dbContext.Hospitals.Add(s);
            await _dbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetHospitals), new { id = s.HId }, s);
            }
            else
            {
                return StatusCode(403, "Hospital with this Email already exists!");
            }
        }


        // PutHospital Method
        [HttpPut("{id}")]
        public async Task<ActionResult> PutHospital(int id, Hospital model)
        {
            if (id != model.HId)
            {
                return BadRequest();
            }

            var hospital = await _dbContext.Hospitals.FindAsync(id);

            if (hospital == null)
            {
                return NotFound();
            }
            if (model.HName != null)
            {
                hospital.HName = model.HName;
            }
            if (model.HAddress != null)
            {
                hospital.HAddress = model.HAddress;
            }

            if (model.HlLatitude != null)
            {
                hospital.HlLatitude = model.HlLatitude;
            }
            if (model.HlLongitude != null)
            {
                hospital.HlLongitude = model.HlLongitude;
            }
            if (!string.IsNullOrEmpty(model.HPassword))
            {
                // Hash the new password
                string hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.HPassword);
                hospital.HPassword = hashedPassword;

                // Update the password for the associated user
                var user = await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == hospital.HEmail);
                if (user != null)
                {
                    user.Password = hashedPassword;
                }
            }



            _dbContext.Entry(hospital).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HospitalAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();
        }



        private bool HospitalAvailable(int id)
        {
            return (_dbContext.Hospitals?.Any(x => x.HId == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> DeleteHospital(int id)
        {
            if (_dbContext.Hospitals == null)
            {
                return NotFound();
            }
            var stud = await _dbContext.Hospitals.FindAsync(id);

            if (stud == null)
            {
                return NotFound();
            }
            _dbContext.Hospitals.Remove(stud);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }


        
    }
}
