﻿namespace LifeLineApi.Models
{
    public class DoctorAppointmentQuery
    {
        public int DoctorId { get; set; }
        public DateTime AppointmentDate { get; set; }
    }

}
