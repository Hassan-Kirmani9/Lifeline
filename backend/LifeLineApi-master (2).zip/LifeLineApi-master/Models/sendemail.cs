﻿namespace LifeLineApi.Models
{
    public class sendemail
    {
        public string email { get; set; }
        public string doctor { get; set; }

        public string link { get; set; }
    }
}
